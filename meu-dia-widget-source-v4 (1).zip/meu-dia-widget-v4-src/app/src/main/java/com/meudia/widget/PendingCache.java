package com.meudia.widget;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

public class PendingCache {
    private static final String PREFS = "meu_dia_widget_cache";
    private static final String KEY = "today_pending";

    public static void write(Context context, List<ActivityItem> items) {
        JSONArray a = new JSONArray();
        for (ActivityItem item : WidgetLogic.getTodayPending(items)) {
            a.put(WidgetLogic.formatPendingLine(item));
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY, a.toString()).apply();
    }

    public static List<String> read(Context context) {
        List<String> out = new ArrayList<>();
        String raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]");
        try {
            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < a.length(); i++) out.add(a.optString(i));
        } catch (Exception ignored) { }
        return out;
    }

    public static void clear(Context context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply();
    }
}
