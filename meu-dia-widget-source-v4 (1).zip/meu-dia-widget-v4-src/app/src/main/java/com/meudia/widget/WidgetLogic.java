package com.meudia.widget;

import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class WidgetLogic {
    private static final ZoneId RECIFE = ZoneId.of("America/Recife");
    private static final Locale PT_BR = new Locale("pt", "BR");

    public static WidgetSnapshot summarize(List<ActivityItem> items) {
        WidgetSnapshot s = new WidgetSnapshot();
        ZonedDateTime now = ZonedDateTime.now(RECIFE);
        List<ActivityItem> todayPending = getTodayPending(items, now);
        List<ActivityItem> events = new ArrayList<>();
        List<ActivityItem> shifts = new ArrayList<>();
        List<ActivityItem> todayEvents = new ArrayList<>();

        for (ActivityItem a : items) {
            boolean isTask = "tarefa".equals(a.kind) || "pagamento".equals(a.kind);
            if (!isTask && a.startsAt != null) {
                events.add(a);
                ZonedDateTime start = a.startsAt.atZoneSameInstant(RECIFE);
                ZonedDateTime end = a.endsAt != null ? a.endsAt.atZoneSameInstant(RECIFE) : start.plusMinutes(1);
                if (!now.toLocalDate().isBefore(start.toLocalDate()) && !now.toLocalDate().isAfter(end.toLocalDate())) {
                    todayEvents.add(a);
                }
                if ("plantao".equals(a.kind) && end.isAfter(now)) shifts.add(a);
            }
        }

        events.sort(Comparator.comparing(a -> a.startsAt));
        shifts.sort(Comparator.comparing(a -> a.startsAt));
        todayEvents.sort(Comparator.comparing(a -> a.startsAt));

        s.pendingCount = todayPending.size();
        s.pendingText = todayPending.isEmpty()
                ? "Nenhuma pendência hoje"
                : todayPending.size() + (todayPending.size() == 1 ? " pendência hoje" : " pendências hoje");

        ActivityItem next = null;
        for (ActivityItem a : events) {
            ZonedDateTime start = a.startsAt.atZoneSameInstant(RECIFE);
            ZonedDateTime end = a.endsAt != null ? a.endsAt.atZoneSameInstant(RECIFE) : start.plusMinutes(1);
            if (end.isAfter(now)) { next = a; break; }
        }
        if (next != null) {
            s.nextEventTitle = emoji(next.kind) + " " + next.title;
            s.nextEventWhen = formatWhen(next, now);
        }

        if (!todayEvents.isEmpty()) {
            ActivityItem t = todayEvents.get(0);
            s.todayText = emoji(t.kind) + " " + t.title + " • " + formatTime(t.startsAt);
        }

        if (!shifts.isEmpty()) {
            ActivityItem sh = shifts.get(0);
            s.nextShiftText = sh.title + " • " + formatDayTime(sh.startsAt);
        }
        return s;
    }

    public static List<ActivityItem> getTodayPending(List<ActivityItem> items) {
        return getTodayPending(items, ZonedDateTime.now(RECIFE));
    }

    private static List<ActivityItem> getTodayPending(List<ActivityItem> items, ZonedDateTime now) {
        List<ActivityItem> out = new ArrayList<>();
        for (ActivityItem a : items) {
            boolean isTask = "tarefa".equals(a.kind) || "pagamento".equals(a.kind);
            boolean pendingStatus = !"concluido".equals(a.status) && !"cancelado".equals(a.status);
            if (!isTask || !pendingStatus || a.startsAt == null) continue;
            ZonedDateTime due = a.startsAt.atZoneSameInstant(RECIFE);
            if (due.toLocalDate().equals(now.toLocalDate())) out.add(a);
        }
        out.sort(Comparator.comparing(a -> a.startsAt, Comparator.nullsLast(Comparator.naturalOrder())));
        return out;
    }

    public static String formatPendingLine(ActivityItem a) {
        String prefix = "pagamento".equals(a.kind) ? "💳" : "☐";
        String time = a.startsAt == null ? "" : " • " + formatTime(a.startsAt);
        return prefix + " " + a.title + time;
    }

    private static String emoji(String kind) {
        if ("plantao".equals(kind)) return "🌙";
        if ("residencia".equals(kind)) return "🩺";
        if ("compromisso".equals(kind)) return "📅";
        if ("estudo".equals(kind)) return "📚";
        return "•";
    }

    private static String formatWhen(ActivityItem a, ZonedDateTime now) {
        ZonedDateTime start = a.startsAt.atZoneSameInstant(RECIFE);
        if (start.toLocalDate().equals(now.toLocalDate())) return "Hoje • " + formatTime(a.startsAt);
        if (start.toLocalDate().equals(now.toLocalDate().plusDays(1))) return "Amanhã • " + formatTime(a.startsAt);
        return start.format(DateTimeFormatter.ofPattern("dd/MM • HH:mm", PT_BR));
    }

    private static String formatTime(OffsetDateTime t) {
        if (t == null) return "—";
        return t.atZoneSameInstant(RECIFE).format(DateTimeFormatter.ofPattern("HH:mm", PT_BR));
    }

    private static String formatDayTime(OffsetDateTime t) {
        if (t == null) return "—";
        return t.atZoneSameInstant(RECIFE).format(DateTimeFormatter.ofPattern("dd/MM HH:mm", PT_BR));
    }
}
