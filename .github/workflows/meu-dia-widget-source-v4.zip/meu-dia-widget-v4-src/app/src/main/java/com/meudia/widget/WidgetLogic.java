package com.meudia.widget;

import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class WidgetLogic {
    private static final ZoneId RECIFE = ZoneId.of("America/Recife");
    private static final Locale PT_BR = new Locale("pt", "BR");

    public static WidgetSnapshot summarize(List<ActivityItem> items) {
        WidgetSnapshot s = new WidgetSnapshot();
        ZonedDateTime now = ZonedDateTime.now(RECIFE);
        List<ActivityItem> pending = new ArrayList<>();
        List<ActivityItem> events = new ArrayList<>();
        List<ActivityItem> shifts = new ArrayList<>();
        List<ActivityItem> todayEvents = new ArrayList<>();

        for (ActivityItem a : items) {
            boolean isTask = "tarefa".equals(a.kind) || "pagamento".equals(a.kind);
            boolean pendingStatus = !"concluido".equals(a.status) && !"cancelado".equals(a.status);
            if (isTask && pendingStatus) pending.add(a);
            if (!isTask && a.startsAt != null) {
                events.add(a);
                ZonedDateTime start = a.startsAt.atZoneSameInstant(RECIFE);
                ZonedDateTime end = a.endsAt != null ? a.endsAt.atZoneSameInstant(RECIFE) : start.plusMinutes(1);
                if (!now.toLocalDate().isBefore(start.toLocalDate()) && !now.toLocalDate().isAfter(end.toLocalDate())) {
                    todayEvents.add(a);
                }
                if ("plantao".equals(a.kind) && end.isAfter(now)) shifts.add(a);
            }
        }

        pending.sort(Comparator.comparing(a -> a.startsAt, Comparator.nullsLast(Comparator.naturalOrder())));
        events.sort(Comparator.comparing(a -> a.startsAt));
        shifts.sort(Comparator.comparing(a -> a.startsAt));
        todayEvents.sort(Comparator.comparing(a -> a.startsAt));

        s.pendingCount = pending.size();
        if (pending.isEmpty()) {
            s.pendingText = "Tudo em dia";
        } else {
            StringBuilder p = new StringBuilder();
            p.append(pending.size()).append(" • ").append(pending.get(0).title);
            if (pending.size() > 1) p.append(" • ").append(pending.get(1).title);
            s.pendingText = p.toString();
        }

        ActivityItem next = null;
        for (ActivityItem a : events) {
            ZonedDateTime start = a.startsAt.atZoneSameInstant(RECIFE);
            ZonedDateTime end = a.endsAt != null ? a.endsAt.atZoneSameInstant(RECIFE) : start.plusMinutes(1);
            if (end.isAfter(now)) { next = a; break; }
        }
        if (next != null) {
            s.nextEventTitle = emoji(next.kind) + " " + next.title;
            s.nextEventWhen = formatWhen(next, now);
        }

        if (!todayEvents.isEmpty()) {
            ActivityItem t = todayEvents.get(0);
            s.todayText = emoji(t.kind) + " " + t.title + " • " + formatTime(t.startsAt);
        }

        if (!shifts.isEmpty()) {
            ActivityItem sh = shifts.get(0);
            s.nextShiftText = sh.title + " • " + formatDayTime(sh.startsAt);
        }
        return s;
    }

    private static String emoji(String kind) {
        if ("plantao".equals(kind)) return "🌙";
        if ("residencia".equals(kind)) return "🩺";
        if ("compromisso".equals(kind)) return "📅";
        if ("estudo".equals(kind)) return "📚";
        return "•";
    }

    private static String formatWhen(ActivityItem a, ZonedDateTime now) {
        ZonedDateTime start = a.startsAt.atZoneSameInstant(RECIFE);
        if (start.toLocalDate().equals(now.toLocalDate())) return "Hoje • " + formatTime(a.startsAt);
        if (start.toLocalDate().equals(now.toLocalDate().plusDays(1))) return "Amanhã • " + formatTime(a.startsAt);
        return start.format(DateTimeFormatter.ofPattern("dd/MM • HH:mm", PT_BR));
    }

    private static String formatTime(OffsetDateTime t) {
        if (t == null) return "—";
        return t.atZoneSameInstant(RECIFE).format(DateTimeFormatter.ofPattern("HH:mm", PT_BR));
    }

    private static String formatDayTime(OffsetDateTime t) {
        if (t == null) return "—";
        return t.atZoneSameInstant(RECIFE).format(DateTimeFormatter.ofPattern("dd/MM HH:mm", PT_BR));
    }
}
