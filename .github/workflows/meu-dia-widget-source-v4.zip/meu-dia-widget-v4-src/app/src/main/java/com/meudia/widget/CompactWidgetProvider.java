package com.meudia.widget;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.BroadcastReceiver.PendingResult;
import android.content.Context;
import android.content.Intent;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CompactWidgetProvider extends AppWidgetProvider {
    public static final String ACTION_REFRESH = "com.meudia.widget.REFRESH_COMPACT";

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        refreshFromReceiver(context, goAsync());
    }

    @Override public void onReceive(Context context, Intent intent) {
        if (ACTION_REFRESH.equals(intent.getAction())) {
            refreshFromReceiver(context, goAsync());
            return;
        }
        super.onReceive(context, intent);
    }

    public static void refresh(Context context) {
        runRefresh(context, null);
    }

    private static void refreshFromReceiver(Context context, PendingResult pending) {
        runRefresh(context, pending);
    }

    private static void runRefresh(Context context, PendingResult pending) {
        ExecutorService ex = Executors.newSingleThreadExecutor();
        ex.execute(() -> {
            try {
                SupabaseClient client = new SupabaseClient(context);
                if (!client.isLoggedIn()) {
                    WidgetRenderer.renderNeedsLogin(context, true, "Toque para entrar e ativar");
                } else {
                    List<ActivityItem> items = client.fetchActivities();
                    WidgetRenderer.renderCompact(context, WidgetLogic.summarize(items));
                }
            } catch (Exception e) {
                WidgetRenderer.renderNeedsLogin(context, true, "Erro ao atualizar • toque para abrir");
            } finally {
                if (pending != null) pending.finish();
                ex.shutdown();
            }
        });
    }
}
