package com.meudia.widget;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

public class SupabaseClient {
    // Public frontend credentials. Data access remains protected by Supabase RLS.
    public static final String SUPABASE_URL = "https://azhjebwqxhqnhxkjhmgt.supabase.co";
    public static final String PUBLISHABLE_KEY = "sb_publishable_Ua25cGprOWU3a9jSg-6iVA_0Vkz6dkl";
    private static final String PREFS = "meu_dia_auth";

    private final Context context;

    public SupabaseClient(Context context) {
        this.context = context.getApplicationContext();
    }

    public boolean isLoggedIn() {
        return getPrefs().getString("refresh_token", null) != null;
    }

    public String login(String email, String password) throws Exception {
        JSONObject body = new JSONObject();
        body.put("email", email);
        body.put("password", password);
        JSONObject result = requestJson("POST", "/auth/v1/token?grant_type=password", body, null);
        saveSession(result);
        return result.optJSONObject("user") != null ? result.getJSONObject("user").optString("email", email) : email;
    }

    public void logout() {
        getPrefs().edit().clear().apply();
    }

    public List<ActivityItem> fetchActivities() throws Exception {
        String access = ensureAccessToken();
        String path = "/rest/v1/activities?select=id,title,kind,status,starts_at,ends_at,location&status=neq.cancelado&order=starts_at.asc&limit=200";
        HttpURLConnection conn = open("GET", path, access);
        int code = conn.getResponseCode();
        if (code == 401) {
            access = refreshAccessToken();
            conn.disconnect();
            conn = open("GET", path, access);
            code = conn.getResponseCode();
        }
        String raw = readBody(conn, code);
        if (code < 200 || code >= 300) throw new Exception("Supabase HTTP " + code + ": " + raw);

        JSONArray array = new JSONArray(raw);
        List<ActivityItem> items = new ArrayList<>();
        for (int i = 0; i < array.length(); i++) {
            JSONObject o = array.getJSONObject(i);
            ActivityItem item = new ActivityItem();
            item.id = o.optString("id");
            item.title = o.optString("title");
            item.kind = o.optString("kind");
            item.status = o.optString("status");
            item.location = o.isNull("location") ? null : o.optString("location");
            item.startsAt = parseTime(o.optString("starts_at", null));
            item.endsAt = parseTime(o.optString("ends_at", null));
            items.add(item);
        }
        return items;
    }

    private OffsetDateTime parseTime(String value) {
        try {
            if (value == null || value.isEmpty() || "null".equals(value)) return null;
            return OffsetDateTime.parse(value);
        } catch (Exception e) {
            return null;
        }
    }

    private String ensureAccessToken() throws Exception {
        SharedPreferences p = getPrefs();
        String access = p.getString("access_token", null);
        long expiresAt = p.getLong("expires_at", 0L);
        if (access == null || System.currentTimeMillis() > expiresAt - 60_000L) {
            return refreshAccessToken();
        }
        return access;
    }

    private String refreshAccessToken() throws Exception {
        String refresh = getPrefs().getString("refresh_token", null);
        if (refresh == null) throw new Exception("Sessão ausente. Abra o app Meu Dia e entre novamente.");
        JSONObject body = new JSONObject();
        body.put("refresh_token", refresh);
        JSONObject result = requestJson("POST", "/auth/v1/token?grant_type=refresh_token", body, null);
        saveSession(result);
        return result.getString("access_token");
    }

    private void saveSession(JSONObject result) throws Exception {
        String access = result.getString("access_token");
        String refresh = result.getString("refresh_token");
        long expiresIn = result.optLong("expires_in", 3600L);
        getPrefs().edit()
                .putString("access_token", access)
                .putString("refresh_token", refresh)
                .putLong("expires_at", System.currentTimeMillis() + expiresIn * 1000L)
                .apply();
    }

    private JSONObject requestJson(String method, String path, JSONObject body, String accessToken) throws Exception {
        HttpURLConnection conn = open(method, path, accessToken);
        if (body != null) {
            conn.setDoOutput(true);
            byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
            try (OutputStream out = conn.getOutputStream()) { out.write(bytes); }
        }
        int code = conn.getResponseCode();
        String raw = readBody(conn, code);
        if (code < 200 || code >= 300) throw new Exception("Supabase HTTP " + code + ": " + raw);
        return new JSONObject(raw);
    }

    private HttpURLConnection open(String method, String path, String accessToken) throws Exception {
        URL url = new URL(SUPABASE_URL + path);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod(method);
        conn.setConnectTimeout(12_000);
        conn.setReadTimeout(15_000);
        conn.setRequestProperty("apikey", PUBLISHABLE_KEY);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Accept", "application/json");
        if (accessToken != null) conn.setRequestProperty("Authorization", "Bearer " + accessToken);
        return conn;
    }

    private String readBody(HttpURLConnection conn, int code) throws Exception {
        InputStream stream = code >= 200 && code < 400 ? conn.getInputStream() : conn.getErrorStream();
        if (stream == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
        }
        return sb.toString();
    }

    private SharedPreferences getPrefs() {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
