package com.meudia.widget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.RemoteViews;

import java.time.ZonedDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class WidgetRenderer {
    public static void updateAll(Context context) {
        CompactWidgetProvider.refresh(context);
        LargeWidgetProvider.refresh(context);
    }

    public static void renderCompact(Context context, WidgetSnapshot s) {
        RemoteViews v = new RemoteViews(context.getPackageName(), R.layout.widget_compact);
        v.setTextViewText(R.id.compactPending, "✅ " + s.pendingCount);
        v.setTextViewText(R.id.compactTitle, s.nextEventTitle);
        v.setTextViewText(R.id.compactSubtitle, s.nextEventWhen);
        v.setOnClickPendingIntent(R.id.widgetRoot, openApp(context, 101));
        v.setOnClickPendingIntent(R.id.compactRefresh, refreshIntent(context, CompactWidgetProvider.class, CompactWidgetProvider.ACTION_REFRESH, 102));
        AppWidgetManager m = AppWidgetManager.getInstance(context);
        m.updateAppWidget(new ComponentName(context, CompactWidgetProvider.class), v);
    }

    public static void renderLarge(Context context, WidgetSnapshot s) {
        RemoteViews v = new RemoteViews(context.getPackageName(), R.layout.widget_large);
        v.setTextViewText(R.id.largeToday, "Hoje: " + s.todayText);
        v.setTextViewText(R.id.largePending, "✅ Pendências: " + s.pendingText);
        v.setTextViewText(R.id.largeShift, "🌙 Próximo plantão: " + s.nextShiftText);
        String updated = ZonedDateTime.now(ZoneId.of("America/Recife")).format(DateTimeFormatter.ofPattern("HH:mm"));
        v.setTextViewText(R.id.largeUpdated, "↻ " + updated);
        v.setOnClickPendingIntent(R.id.widgetRoot, openApp(context, 201));
        v.setOnClickPendingIntent(R.id.largeOpen, openWeb(context, 202));
        v.setOnClickPendingIntent(R.id.largeRefresh, refreshIntent(context, LargeWidgetProvider.class, LargeWidgetProvider.ACTION_REFRESH, 203));
        AppWidgetManager m = AppWidgetManager.getInstance(context);
        m.updateAppWidget(new ComponentName(context, LargeWidgetProvider.class), v);
    }

    public static void renderNeedsLogin(Context context, boolean compact, String message) {
        if (compact) {
            RemoteViews v = new RemoteViews(context.getPackageName(), R.layout.widget_compact);
            v.setTextViewText(R.id.compactPending, "🔒");
            v.setTextViewText(R.id.compactTitle, "Meu Dia");
            v.setTextViewText(R.id.compactSubtitle, message);
            v.setOnClickPendingIntent(R.id.widgetRoot, openApp(context, 301));
            AppWidgetManager.getInstance(context).updateAppWidget(new ComponentName(context, CompactWidgetProvider.class), v);
        } else {
            RemoteViews v = new RemoteViews(context.getPackageName(), R.layout.widget_large);
            v.setTextViewText(R.id.largeToday, "Abra o app Meu Dia");
            v.setTextViewText(R.id.largePending, message);
            v.setTextViewText(R.id.largeShift, "Depois adicione o widget novamente se necessário.");
            v.setOnClickPendingIntent(R.id.widgetRoot, openApp(context, 302));
            AppWidgetManager.getInstance(context).updateAppWidget(new ComponentName(context, LargeWidgetProvider.class), v);
        }
    }

    private static PendingIntent openApp(Context context, int requestCode) {
        Intent i = new Intent(context, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(context, requestCode, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static PendingIntent openWeb(Context context, int requestCode) {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://meu-dia-next.vercel.app"));
        return PendingIntent.getActivity(context, requestCode, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static PendingIntent refreshIntent(Context context, Class<?> cls, String action, int requestCode) {
        Intent i = new Intent(context, cls);
        i.setAction(action);
        return PendingIntent.getBroadcast(context, requestCode, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
