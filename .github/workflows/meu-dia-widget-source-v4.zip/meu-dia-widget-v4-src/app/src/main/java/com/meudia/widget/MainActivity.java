package com.meudia.widget;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private TextView status;
    private EditText email;
    private EditText password;
    private Button login;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        status = findViewById(R.id.statusText);
        email = findViewById(R.id.emailInput);
        password = findViewById(R.id.passwordInput);
        login = findViewById(R.id.loginButton);
        Button refresh = findViewById(R.id.refreshButton);
        Button web = findViewById(R.id.openWebButton);
        Button logout = findViewById(R.id.logoutButton);

        SupabaseClient client = new SupabaseClient(this);
        if (client.isLoggedIn()) status.setText("Sessão ativa. Seus widgets podem sincronizar com o Meu Dia.");

        login.setOnClickListener(v -> doLogin());
        refresh.setOnClickListener(v -> {
            status.setText("Atualizando widgets…");
            WidgetRenderer.updateAll(this);
            status.postDelayed(() -> status.setText("Atualização solicitada. Veja os widgets na tela inicial."), 1200);
        });
        web.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://meu-dia-next.vercel.app"))));
        logout.setOnClickListener(v -> {
            new SupabaseClient(this).logout();
            status.setText("Sessão removida deste dispositivo.");
            WidgetRenderer.updateAll(this);
        });
    }

    private void doLogin() {
        String e = email.getText().toString().trim();
        String p = password.getText().toString();
        if (e.isEmpty() || p.isEmpty()) {
            status.setText("Preencha e-mail e senha.");
            return;
        }
        login.setEnabled(false);
        status.setText("Entrando e sincronizando…");
        executor.execute(() -> {
            try {
                SupabaseClient client = new SupabaseClient(this);
                String account = client.login(e, p);
                List<ActivityItem> items = client.fetchActivities();
                WidgetSnapshot snap = WidgetLogic.summarize(items);
                runOnUiThread(() -> {
                    status.setText("Conectado: " + account + "\n" + snap.pendingCount + " pendência(s). Widgets ativados.");
                    password.setText("");
                    WidgetRenderer.renderCompact(this, snap);
                    WidgetRenderer.renderLarge(this, snap);
                    login.setEnabled(true);
                });
            } catch (Exception ex) {
                runOnUiThread(() -> {
                    status.setText("Não foi possível entrar: " + simplify(ex.getMessage()));
                    login.setEnabled(true);
                });
            }
        });
    }

    private String simplify(String message) {
        if (message == null) return "erro desconhecido";
        if (message.contains("Invalid login credentials")) return "e-mail ou senha incorretos";
        if (message.length() > 180) return message.substring(0, 180) + "…";
        return message;
    }

    @Override protected void onDestroy() {
        executor.shutdown();
        super.onDestroy();
    }
}
