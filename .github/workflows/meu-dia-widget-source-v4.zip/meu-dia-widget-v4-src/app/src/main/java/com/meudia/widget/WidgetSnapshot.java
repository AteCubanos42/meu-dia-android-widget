package com.meudia.widget;

public class WidgetSnapshot {
    public int pendingCount;
    public String nextEventTitle = "Nenhum evento futuro";
    public String nextEventWhen = "Tudo livre por enquanto";
    public String todayText = "—";
    public String pendingText = "Tudo em dia";
    public String nextShiftText = "Nenhum plantão futuro";
}
