package com.meudia.widget;

import java.time.OffsetDateTime;

public class ActivityItem {
    public String id;
    public String title;
    public String kind;
    public String status;
    public String location;
    public OffsetDateTime startsAt;
    public OffsetDateTime endsAt;
}
