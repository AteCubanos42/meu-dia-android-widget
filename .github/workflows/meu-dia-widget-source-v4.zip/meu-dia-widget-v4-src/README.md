# Meu Dia — Android Widgets

Aplicativo Android nativo complementar ao **Meu Dia Web**.

## O que entrega
- Widget compacto: próximo evento + número de pendências.
- Widget resumo: evento de hoje + até 2 pendências + próximo plantão.
- Atualização manual e periódica (Android pode postergar atualizações por economia de bateria).
- Login direto no mesmo Supabase do Meu Dia.
- Reutiliza o mesmo banco e as políticas RLS já existentes.

## Segurança
O APK contém somente a URL do projeto Supabase e a `publishable key`, que é uma credencial pública destinada ao frontend. O acesso aos dados exige sessão autenticada e permanece protegido por Row Level Security (RLS).

## Como usar
1. Instale o APK.
2. Abra “Meu Dia”.
3. Entre com o mesmo e-mail/senha usados no site.
4. Na tela inicial Samsung: toque e segure → Widgets → Meu Dia.
5. Escolha **Compacto** ou **Resumo**.

## Build
Projeto sem bibliotecas externas no runtime; usa APIs nativas Android.
- compileSdk 35
- minSdk 26
- targetSdk 35
